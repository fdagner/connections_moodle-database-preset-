# connections_moodle-database-preset-
Moodle mod_data variant of NYT's connection game. Group words by topic.
